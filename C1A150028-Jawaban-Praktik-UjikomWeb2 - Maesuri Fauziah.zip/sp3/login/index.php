<?php 
    
session_start();
if(isset($_SESSION['status']) && $_SESSION['status']=="login"){
    header("location:./index.php");
}
    
$pesan = "";

if(isset($_GET['pesan'])){
	if($_GET['pesan'] == "gagal"){
		$pesan =  "Login gagal! username dan password salah!";
	}else if($_GET['pesan'] == "logout"){
		$pesan =  "Anda telah berhasil logout";
	}else if($_GET['pesan'] == "belum_login"){
		$pesan =  "Anda harus login untuk mengakses halaman admin";
	}else{
        $pesan =  "Please Sign In";
    }
}
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>UjiKom Junior Web Programing Universitas Bale Bandung</title>

    <!-- Core CSS - Include with every page -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- SB Admin CSS - Include with every page -->
    <link href="../assets/css/sb-admin.css" rel="stylesheet">

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading" align="center">
                        <img width="100px" height="100px" src="../assets/img/logo.png" /><br /><br />
                        <h3 class="panel-title"><?php echo $pesan;?></h3>
                    </div>
                    <div class="panel-body">
                        <form action="cekuser.php" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="username" type="text"
                                        autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password"
                                        value="">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <button name="login">Log In</button> 
                                
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core Scripts - Include with every page -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- SB Admin Scripts - Include with every page -->
    <script src="../assets/js/sb-admin.js"></script>

</body>

</html>