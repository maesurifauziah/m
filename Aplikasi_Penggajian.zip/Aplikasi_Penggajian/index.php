<!-- cek apakah sudah login -->
<?php 
	session_start();
	if($_SESSION['status']!="login"){
        header("location:./login/index.php");
        
        
    }
    
    
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>APLIKASI PENGGAJIAN</title>

    <!-- Core CSS - Include with every page -->
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="./assets/css/datepicker.css" rel="stylesheet">
    <link href="./assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Page-Level Plugin CSS - Blank -->

    <!-- SB Admin CSS - Include with every page -->
    <link href="./assets/css/sb-admin.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- /.<a class="navbar-brand" >APLIKASI PENGGAJIAN</a> -->
                <font size="4">APLIKASI PENGGAJIAN</font>
                <br>
                <font size="3">PT. XYZ</font>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <?php echo $_SESSION['username'];?> <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="login/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
            <br>
            <br>

            <div class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="./index.php"><i class="fa fa-home fa-fw"></i> Home</a>
                        </li>
                        <li>
                            <a href="./jabatan/index.php"><i class="fa fa-user fa-fw"></i> Jabatan</a>
                        </li>
                        <li>
                            <a href="./jenis-tunjangan/index.php"><i class="fa fa-files-o fa-fw"></i> Jenis Tunjangan</a>
                        </li>
                        <li>
                            <a href="./karyawan/index.php"><i class="fa fa-files-o fa-fw"></i> Karyawan</a>
                        </li>
                        <li>
                            <a href="./tunjangan-jabatan/index.php"><i class="fa fa-tasks fa-fw"></i> Tunjangan Jabatan</a>
                        </li>
                        <li>
                            <a href="./absensi/index.php"><i class="fa fa-tasks fa-fw"></i> Absensi</a>
                        </li>
                        <li>
                            <a href="./struk-gaji/index.php"><i class="fa fa-tasks fa-fw"></i> Struk Gaji</a>
                        </li>
                       
                        
                    </ul>
                    <!-- /#side-menu -->
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Home</h1>
                </div>
                <!-- /.col-lg-12 -->
                <div class="widget-content">
                    Selamat datang di Aplikasi Penggajian<br/>
                    PT. XYZ
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /#page-wrapper -->
    </div> <!-- /#wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="./assets/js/jquery-1.10.2.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <script src="./assets/js/bootstrap-datepicker.js"></script>
    <script src="./assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Page-Level Plugin Scripts - Blank -->

    <!-- SB Admin Scripts - Include with every page -->
    <script src="./assets/js/sb-admin.js"></script>

    <!-- Page-Level Demo Scripts - Blank - Use for reference -->

</body>

</html>