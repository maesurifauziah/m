<!-- cek apakah sudah login -->
<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:./login/index.php");
	}
    ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>APLIKASI PENGGAJIAN</title>

    <!-- Core CSS - Include with every page -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Page-Level Plugin CSS - Tables -->
    <link href="../assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <!-- SB Admin CSS - Include with every page -->
    <link href="../assets/css/sb-admin.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <font size="4">APLIKASI PENGGAJIAN</font>
                <br>
                <font size="3">PT. XYZ</font>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    <?php echo $_SESSION['username'];?> <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="../login/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
            <br><br>

            <div class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav" id="side-menu">
                    <li>
                            <a href="../index.php"><i class="fa fa-home fa-fw"></i> Home</a>
                        </li>
                        <li>
                            <a href="../jabatan/index.php"><i class="fa fa-user fa-fw"></i> Jabatan</a>
                        </li>
                        <li>
                            <a href="../jenis-tunjangan/index.php"><i class="fa fa-files-o fa-fw"></i> Jenis Tunjangan</a>
                        </li>
                        <li>
                            <a href="../karyawan/index.php"><i class="fa fa-files-o fa-fw"></i> Karyawan</a>
                        </li>
                        <li>
                            <a href="../tunjangan-jabatan/index.php"><i class="fa fa-tasks fa-fw"></i> Tunjangan Jabatan</a>
                        </li>
                        <li>
                            <a href="../absensi/index.php"><i class="fa fa-tasks fa-fw"></i> Absensi</a>
                        </li>
                        <li>
                            <a href="../struk-gaji/index.php"><i class="fa fa-tasks fa-fw"></i> Struk Gaji</a>
                        </li>  

                    </ul>
                    <!-- /#side-menu -->
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Absensi</h1>
                </div>
                <!-- /.col-lg-12 -->

                <div class="panel-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Tambah Absensi</button>
                    <a href="../absensi/laporan_absensi.php"><button type="button" class="btn btn-info">Laporan Absensi</button><br /><br /></a>
                    <div class="grid-24">
                       <div class="widget widget-table">
                            <div class="widget-header">
                                <span class="icon-list"></span>
                                <h3 class="icon chart">Data Karyawan</h3>
                            </div>
                            <div class="widget-content">
                                <div class="dataTables_length" id="dataTables-example_length">
                                    <label>
                                        records per page
                                         <select name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select>                                                         
                                    </label>
                                </div>
                                <div class="dataTables_filter"><label>Pencarian: <input type="text"></label></div>
                                <table class="table table-bordered table-striped data-table">
                                    <thead>
                                        <tr>
                                            <th class="ui-state-default" rowspan="1" colspan="1" style="width: 7%;">
                                                No.
                                            </th>
                                            <th class="ui-state-default" rowspan="1" colspan="1" style="width: 10%;">
                                                NIP
                                            </th>
                                            <th class="ui-state-default" rowspan="1" colspan="1" style="width: 23%;">
                                                Nama Karyawan
                                            </th>
                                            <th class="ui-state-default" rowspan="1" colspan="1" style="width: 10%;">
                                                Aksi
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                            <tr class="gradeA odd">
                                                <td>No</td>
                                                <td>NIP</td>
                                                <td>Nama Karyawan</td>
                                                <td>
                                                    <a><button class="btn btn-success btn-xs" data-toggle="modal" data-target="#modalDetail">Lihat Absensi</button></a>
                                                    <a><button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#modalRekap">Rekap Absensi</button></a>
                                                </td>
                                            </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div> <!-- .widget-content -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->
        </div>
        <!-- /#wrapper -->


        <!-- Modal Tambah -->
        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog modal-lg">
                <!-- konten modal-->
                <div class="modal-content">
                    <!-- heading modal -->
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Tambah Absensi</h4>
                    </div>
                    <!-- body modal -->
                    <div class="modal-body">
                    <div class="actions" align="right">
                        <label style="font-weight:bold;font-size:14px">Tanggal Absensi : </label><input type="text" name="tgl_absensi" id="datepicker" value="<?php echo date('d/m/Y'); ?>" style="background-color:orange" class="validate[required]">
                    </div> <!-- .actions -->
                        <input type="hidden" name="jumlah_data" value="<?php echo $hasil; ?>"/>
            
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 5%;">
                                        No.
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 16%;">
                                        NIP
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 30%;">
                                        Nama Karyawan
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 30%;">
                                        Kehadiran
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 7%;">
                                        Jam Masuk
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 7%;">
                                        Jam Keluar
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                
                                    <tr class="gradeA odd">
                                        <td>No</td>
                                        <td>NIP</td>
                                        <td>Nama Karyawan</td>
                                        <td>
                                            <div class="field-group inlineField">
                                                <div class="field">
                                                    <label><input type="radio" name="kehadiran<?php echo $i - 1; ?>" value="Alpha" class="validate[required]"/><font size="2">Alpha</font></label>
                                                    <label><input type="radio" name="kehadiran<?php echo $i - 1; ?>" value="Hadir" class="validate[required]"/><font size="2">Hadir</font></label>
                                                    <label><input type="radio" name="kehadiran<?php echo $i - 1; ?>" value="Sakit" class="validate[required]"/><font size="2">Sakir</font></label>
                                                    <label><input type="radio" name="kehadiran<?php echo $i - 1; ?>" value="Ijin" class="validate[required]"/><font size="2">Izin</font></label>
                                                    <label><input type="radio" name="kehadiran<?php echo $i - 1; ?>" value="Cuti" class="validate[required]"/><font size="2">Cuti</font></label>
                                                </div> <!-- .field -->
                                            </div> <!-- .field-group --></td>
                                        <td>
                                            <div class="field-group inlineField">
                                                <div class="field">
                                                    <input type="text" size="7" name="waktu_masuk<?php echo $i - 1; ?>" id="timepicker_masuk<?php echo $i - 1; ?>" value="08:00" class="validate[required]">
                                                </div> <!-- .field -->
                                            </div> <!-- .field-group -->
                                        </td>
                                        <td>
                                            <div class="field-group inlineField">
                                                <div class="field">
                                                    <input type="text" size="7" name="waktu_keluar<?php echo $i - 1; ?>" id="timepicker_keluar<?php echo $i - 1; ?>" value="16:00" class="validate[required]"/>
                                                </div> <!-- .field -->
                                            </div> <!-- .field-group -->
                                        </td>
                                    </tr>
                                <script type='text/javascript'>
                                    $(function(){
                                        $('#timepicker_masuk<?php echo $i - 1; ?>').timepicker ({
                                            showPeriod: true
                                            , showNowButton: true
                                            , showCloseButton: true
                                        });
                                            
                                            
                                        $('#timepicker_keluar<?php echo $i - 1; ?>').timepicker ({
                                            showPeriod: true
                                            , showNowButton: true
                                            , showCloseButton: true
                                        });
                                    });
                                </script>
                           
                            </tbody>
                        </table>

                    </div>
                    <!-- footer modal -->
                    <div class="modal-footer">
                        <button type="submit" name="Submit" class="btn btn-success">Simpan</button>
                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    </div>
                </div>
            </div>
        </div>         
        <!-- ./Modal Tambah -->


        <!-- Modal Detail -->
        <div id="modalDetail" class="modal fade" role="dialog">
            <div class="modal-dialog modal-lg">
                <!-- konten modal-->
                <div class="modal-content">
                    <!-- heading modal -->
                    <div class="modal-header">             
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Data Absensi</h4>
                    </div>
                    <!-- body modal -->
                    <div class="modal-body">
                        <div class="actions" align="right">
                            <label>Pencarian : </label><input type="text" name="cari" id="cari">
                        </div> <!-- .actions -->                     
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 5%;">
                                        No.
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 16%;">
                                        NIP
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 24%;">
                                        Nama Karyawan
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 7%;">
                                        Kehadiran
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 11%;">
                                        Jam Masuk
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 11%;">
                                        Jam Keluar
                                    </th>
                                    <th class="ui-state-default" rowspan="1" colspan="1" style="width: 18%;">
                                        Aksi
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                    <tr class="gradeA odd">
                                        <td>No</td>
                                        <td>NIP</td>
                                        <td>Nama Karyawan</td>
                                        <td>Kehadiran</td>
                                        <td>Jam Masuk</td>
                                        <td>Jam Keluar</td>
                                        <td>
                                            <a><button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#modalUbah">Ubah</button></a>
                                            <a onclick="return confirm('Apakah Anda yakin akan menhapus data?')"><button class="btn btn-danger btn-sm ">Hapus</button></a>
                                        </td>
                                    </tr>
                                <script type='text/javascript'>
                                    $(function(){
                                        $('#timepicker_masuk<?php echo $i - 1; ?>').timepicker ({
                                            showPeriod: true
                                            , showNowButton: true
                                            , showCloseButton: true
                                        });                                            
                                        $('#timepicker_keluar<?php echo $i - 1; ?>').timepicker ({
                                            showPeriod: true
                                            , showNowButton: true
                                            , showCloseButton: true
                                        });
                                    });
                                </script>
                           
                            </tbody>
                        </table>
                    </div>                   
                </div>
            </div>
        </div>         
        <!-- ./Modal Detail -->


        <!-- Modal Ubah -->
        <div id="modalUbah" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                    <!-- heading modal -->
                    <div class="modal-header">             
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Ubah Absensi</h4>
                    </div>
                    <!-- body modal -->
                    <div class="modal-body">
                                         
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 20%;">
                                    Kehadiran
                                </th>
                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 10%;">
                                    Jam Masuk
                                </th>
                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 10%;">
                                    Jam Keluar
                                </th>
                            </tr>
                        </thead>

                        <tbody>
                                <tr class="gradeA odd">
                                    <td>
                                        <div class="field-group inlineField">
                                            <div class="field">
                                                <label><input type="radio" name="kehadiran" value="Alpha" class="validate[required]" /><font size="1">Alpha</font></label>
                                                <label><input type="radio" name="kehadiran" value="Hadir" class="validate[required]" /><font size="1">Hadir</font></label>
                                                <label><input type="radio" name="kehadiran" value="Sakit" class="validate[required]" /><font size="1">Sakit</font></label>
                                                <label><input type="radio" name="kehadiran" value="Ijin" class="validate[required]" /><font size="1">Izin</font></label>
                                                <label><input type="radio" name="kehadiran" value="Cuti" class="validate[required]" /><font size="1">Cuti</font></label>
                                            </div> <!-- .field -->
                                        </div> <!-- .field-group --></td>
                                    <td>
                                        <div class="field-group inlineField">
                                            <div class="field">
                                                <input type="text" name="waktu_masuk" id="timepicker_masuk"  class="validate[required]">
                                            </div> <!-- .field -->
                                        </div> <!-- .field-group -->
                                    </td>
                                    <td>
                                        <div class="field-group inlineField">
                                            <div class="field">
                                                <input type="text" name="waktu_keluar" id="timepicker_keluar"  class="validate[required]"/>
                                            </div> <!-- .field -->
                                        </div> <!-- .field-group -->
                                    </td>
                                </tr>
                            <script type='text/javascript'>
                                $(function(){
                                    $('#timepicker_masuk').timepicker ({
                                        showPeriod: true
                                        , showNowButton: true
                                        , showCloseButton: true
                                    });
                                        
                                        
                                    $('#timepicker_keluar').timepicker ({
                                        showPeriod: true
                                        , showNowButton: true
                                        , showCloseButton: true
                                    });
                                });
                            </script>
                        </tbody>
                    </table>
                    </div>   
                    <!-- footer modal -->
                    <div class="modal-footer">
                        <button type="submit" name="Submit" class="btn btn-success">Simpan</button>
                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    </div>                
                </div>
            </div>
        </div>         
        <!-- ./Modal Ubah -->


        <!-- Modal Rekap -->
        <div id="modalRekap" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- konten modal-->
                <div class="modal-content">
                    <!-- heading modal -->
                    <div class="modal-header">             
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Ubah Absensi</h4>
                    </div>
                    <!-- body modal -->
                    <form >
                    <div class="modal-body">
                    <input type="hidden" name="nip" />
                    <div class="field-group">
                        <div class="field">
                            <label for="expirationmonth">Bulan</label>
                            <select id="bulan" name="bulan">
                                <option value="01">01 - Januari</option>
                                <option value="02">02 - Februari</option>
                                <option value="03">03 - Maret</option>
                                <option value="04">04 - April</option>
                                <option value="05">05 - Mei</option>
                                <option value="06">06 - Juni</option>
                                <option value="07">07 - Juli</option>
                                <option value="08">08 - Agustus</option>
                                <option value="09">09 - September</option>
                                <option value="10">10 - Oktober</option>
                                <option value="11">11 - November</option>
                                <option value="12">12 - Desember</option>			
                            </select>
                        </div>
                        

                        <div class="field">
                            <label for="expirationyear">Tahun</label>
                            <select id="tahun" name="tahun">
                            <?php for ( $i = 2000; $i <= 2050; $i ++) { ?>
                                <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                <?php }?>
                            </select>
                        </div>
                    </div>	
                    </br>                   

                    
                </form>
                    <!-- footer modal -->
                    <div class="modal-footer">
                        <button type="submit" name="Submit" class="btn btn-primary">Cetak</button>
                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    </div>                
                </div>
            </div>
        </div>         
        <!-- ./Modal Rekap -->

        <!-- Core Scripts - Include with every page -->
        <script src="../assets/js/jquery-1.10.2.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>

        <!-- Page-Level Plugin Scripts - Tables -->
        <script src="../assets/js/plugins/dataTables/jquery.dataTables.js"></script>
        <script src="../assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>

        <!-- SB Admin Scripts - Include with every page -->
        <script src="../assets/js/sb-admin.js"></script>

        <!-- Page-Level Demo Scripts - Blank - Use for reference -->
        <script>
        $(document).ready(function() {
            $('#dataTables-example').dataTable();
        });
        </script>
</body>

</html>