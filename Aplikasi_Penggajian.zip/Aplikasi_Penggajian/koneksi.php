<?php 
$koneksi = mysqli_connect("localhost","root","","db_gaji");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}

function autoNumber($koneksi, $kode, $id, $table){
	$result = mysqli_query($koneksi, "SELECT MAX(RIGHT(".$id.", 3)) as max_id FROM ".$table." ORDER BY ".$id); 
	$data = mysqli_fetch_array($result);
	$id_max = $data['max_id'];
	$sort_num = (int) substr($id_max, 1, 3);
	$sort_num++;
	$new_code = $kode.sprintf("%03s", $sort_num);
	return $new_code;
   }
?>