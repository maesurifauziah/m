-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Jan 2020 pada 14.45
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_gaji`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE `absensi` (
  `id_absensi` int(11) NOT NULL,
  `nip` int(11) NOT NULL,
  `kehadiran` varchar(10) NOT NULL,
  `waktu_masuk` time NOT NULL,
  `waktu_keluar` time NOT NULL,
  `tgl_absensi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `absensi`
--

INSERT INTO `absensi` (`id_absensi`, `nip`, `kehadiran`, `waktu_masuk`, `waktu_keluar`, `tgl_absensi`) VALUES
(1, 12345, 'Hadir', '08:00:00', '19:00:00', '2014-06-02'),
(2, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-02'),
(3, 12345, 'Hadir', '08:00:00', '19:00:00', '2014-06-03'),
(5, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-03'),
(6, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-04'),
(7, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-04'),
(8, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-05'),
(9, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-05'),
(10, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-06'),
(11, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-06'),
(12, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-07'),
(13, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-07'),
(14, 12345, 'Sakit', '08:00:00', '16:00:00', '2014-06-09'),
(15, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-09'),
(16, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-10'),
(17, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-10'),
(18, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-11'),
(19, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-11'),
(20, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-12'),
(21, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-12'),
(22, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-13'),
(23, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-13'),
(24, 12345, 'Ijin', '08:00:00', '16:00:00', '2014-06-14'),
(25, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-14'),
(26, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-16'),
(27, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-16'),
(28, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-17'),
(29, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-17'),
(30, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-18'),
(31, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-18'),
(32, 12345, '', '08:00:00', '16:00:00', '2014-06-19'),
(33, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-19'),
(34, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-20'),
(35, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-20'),
(36, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-21'),
(37, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-21'),
(38, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-22'),
(39, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-22'),
(40, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-23'),
(41, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-23'),
(42, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-24'),
(43, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-24'),
(44, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-25'),
(45, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-25'),
(46, 12345, 'Cuti', '08:00:00', '16:00:00', '2014-06-26'),
(47, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-26'),
(48, 12345, 'Cuti', '08:00:00', '16:00:00', '2014-06-27'),
(49, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-27'),
(50, 12345, 'Cuti', '08:00:00', '16:00:00', '2014-06-28'),
(51, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-28'),
(52, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-29'),
(53, 1234567, 'Hadir', '08:00:00', '16:00:00', '2014-06-30'),
(54, 12345, 'Hadir', '08:00:00', '16:00:00', '2014-06-30'),
(55, 12345, '', '07:00:00', '20:00:00', '2014-06-30');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jabatan` int(11) NOT NULL,
  `nama_jabatan` varchar(40) NOT NULL,
  `gapok` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`, `gapok`) VALUES
(1, 'Staff Keuangan', 5000000),
(2, 'Staff Personalia', 2000000),
(3, 'Staff Operator', 1500000),
(4, 'Direktur', 6000000),
(5, 'Sekretaris', 5000000),
(6, 'ob', 1000000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_tunjangan`
--

CREATE TABLE `jenis_tunjangan` (
  `id_jenis_tunjangan` int(11) NOT NULL,
  `nama_jenis_tunjangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis_tunjangan`
--

INSERT INTO `jenis_tunjangan` (`id_jenis_tunjangan`, `nama_jenis_tunjangan`) VALUES
(1, 'Anak'),
(2, 'Istri'),
(3, 'Transportasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE `karyawan` (
  `nip` int(11) NOT NULL,
  `nama_karyawan` varchar(50) NOT NULL,
  `jk` varchar(12) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `alamat_karyawan` text NOT NULL,
  `telp` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `id_jabatan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`nip`, `nama_karyawan`, `jk`, `tempat_lahir`, `tgl_lahir`, `agama`, `alamat_karyawan`, `telp`, `email`, `password`, `foto`, `id_jabatan`) VALUES
(12345, 'Abdullahs', 'Laki-laki', 'Jogja', '1989-04-12', 'Islam', '<p>Ngayogjakarto</p>', '081220428004', 'coba@yahoo.com', '827ccb0eea8a706c4c34a16891f84e7b', 'file/foto_karyawan/default_user.png', 1),
(1111111, 'Dr. Ir. Oviyan Patra, MT.', 'Laki-laki', 'Bandung', '1965-06-06', 'Islam', '<p>Bandung</p>', '0855555554', 'cheppy_sahari@yahoo.com', '7fa8282ad93047a4d6fe6111c93b308a', 'file/foto_karyawan/1111111.jpg', 1),
(1234567, 'Udin', 'Laki-laki', 'Bandung', '1985-06-02', 'Islam', '<p>Bandung</p>', '0855555555', 'cheppy_sahari@yahoo.com', 'fcea920f7412b5da7be0cf42b8c93759', 'file/foto_karyawan/1234567.jpg', 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `staff`
--

CREATE TABLE `staff` (
  `staff_id` varchar(5) NOT NULL COMMENT 'Uniquely identifies a member staf',
  `fname` varchar(15) NOT NULL COMMENT 'First Name of Staff',
  `lname` varchar(15) NOT NULL COMMENT 'Last Name of Staff',
  `dob` date NOT NULL COMMENT 'Date of Birth of Staff',
  `address` varchar(30) NOT NULL COMMENT 'Home Address or contact addres',
  `sex` char(1) NOT NULL COMMENT 'Gender Male M or Femal F',
  `phone` int(10) NOT NULL COMMENT 'Contact Phone Number',
  `role_id` varchar(5) NOT NULL COMMENT 'Job Title ID, Foreign Key',
  `username` varchar(15) NOT NULL COMMENT 'Unique to user, for login function',
  `password` varchar(15) DEFAULT NULL COMMENT 'Unique, encrypted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `staff`
--

INSERT INTO `staff` (`staff_id`, `fname`, `lname`, `dob`, `address`, `sex`, `phone`, `role_id`, `username`, `password`) VALUES
('SF001', 'Admin', 'administratpr', '2019-10-18', 'jl.raa wiranatakusumah no7', 'M', 22595, 'R0001', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tunjangan_jabatan`
--

CREATE TABLE `tunjangan_jabatan` (
  `id_tunjangan_jabatan` int(11) NOT NULL,
  `id_jenis_tunjangan` int(11) NOT NULL,
  `nip` int(11) NOT NULL,
  `besar_tunjangan` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tunjangan_jabatan`
--

INSERT INTO `tunjangan_jabatan` (`id_tunjangan_jabatan`, `id_jenis_tunjangan`, `nip`, `besar_tunjangan`) VALUES
(6, 1, 12345, 200000),
(7, 1, 1111111, 200000),
(8, 1, 1234567, 150000),
(9, 3, 12345, 50000),
(10, 3, 1234567, 50000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id_absensi`),
  ADD KEY `nip` (`nip`);

--
-- Indeks untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indeks untuk tabel `jenis_tunjangan`
--
ALTER TABLE `jenis_tunjangan`
  ADD PRIMARY KEY (`id_jenis_tunjangan`);

--
-- Indeks untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `id_jabatan` (`id_jabatan`);

--
-- Indeks untuk tabel `tunjangan_jabatan`
--
ALTER TABLE `tunjangan_jabatan`
  ADD PRIMARY KEY (`id_tunjangan_jabatan`),
  ADD KEY `nip` (`nip`),
  ADD KEY `id_jenis_tunjangan` (`id_jenis_tunjangan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id_absensi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id_jabatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `jenis_tunjangan`
--
ALTER TABLE `jenis_tunjangan`
  MODIFY `id_jenis_tunjangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `nip` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1234568;

--
-- AUTO_INCREMENT untuk tabel `tunjangan_jabatan`
--
ALTER TABLE `tunjangan_jabatan`
  MODIFY `id_tunjangan_jabatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD CONSTRAINT `nip` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD CONSTRAINT `karyawan_ibfk_1` FOREIGN KEY (`id_jabatan`) REFERENCES `jabatan` (`id_jabatan`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tunjangan_jabatan`
--
ALTER TABLE `tunjangan_jabatan`
  ADD CONSTRAINT `tunjangan_jabatan_ibfk_1` FOREIGN KEY (`id_jenis_tunjangan`) REFERENCES `jenis_tunjangan` (`id_jenis_tunjangan`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tunjangan_jabatan_ibfk_2` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
