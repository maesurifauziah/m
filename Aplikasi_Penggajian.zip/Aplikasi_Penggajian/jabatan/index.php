<!-- cek apakah sudah login -->
<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:./login/index.php");
    }
    
   
    ?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>APLIKASI PENGGAJIAN</title>

    <!-- Core CSS - Include with every page -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Page-Level Plugin CSS - Tables -->
    <link href="../assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <!-- SB Admin CSS - Include with every page -->
    <link href="../assets/css/sb-admin.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <font size="4">APLIKASI PENGGAJIAN</font>
                <br>
                <font size="3">PT. XYZ</font>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    <?php echo $_SESSION['username'];?> <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="../login/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
            <br><br>

            <div class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav" id="side-menu">
                    <li>
                            <a href="../index.php"><i class="fa fa-home fa-fw"></i> Home</a>
                        </li>
                        <li>
                            <a href="../jabatan/index.php"><i class="fa fa-user fa-fw"></i> Jabatan</a>
                        </li>
                        <li>
                            <a href="../jenis-tunjangan/index.php"><i class="fa fa-files-o fa-fw"></i> Jenis Tunjangan</a>
                        </li>
                        <li>
                            <a href="../karyawan/index.php"><i class="fa fa-files-o fa-fw"></i> Karyawan</a>
                        </li>
                        <li>
                            <a href="../tunjangan-jabatan/index.php"><i class="fa fa-tasks fa-fw"></i> Tunjangan Jabatan</a>
                        </li>
                        <li>
                            <a href="../absensi/index.php"><i class="fa fa-tasks fa-fw"></i> Absensi</a>
                        </li>
                        <li>
                            <a href="../struk-gaji/index.php"><i class="fa fa-tasks fa-fw"></i> Struk Gaji</a>
                        </li>  

                    </ul>
                    <!-- /#side-menu -->
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Jabatan</h1>
                </div>
                <!-- /.col-lg-12 -->

                <div class="panel-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Tambah Jabatan</button><br /><br />
                        <div class="grid-24">
                            <div class="widget widget-table">

                                <div class="widget-header">
                                    <span class="icon-list"></span>
                                    <h3 class="icon chart">Data Jabatan</h3>
                                </div>

                                <div class="widget-content">
                                    <div class="dataTables_length" id="dataTables-example_length">
                                                <label>
                                                    records per page
                                                    <select name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">
                                                        <option value="10">10</option>
                                                        <option value="25">25</option>
                                                        <option value="50">50</option>
                                                        <option value="100">100</option>
                                                    </select>                                                         
                                                </label>
                                    </div>
                                    <div class="dataTables_filter"><label>Pencarian: <input type="text"></label></div>

                                    <table>
                                        <tr>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                        </tr>
                                    </table>
                                    
                                    <table class="table table-bordered table-striped data-table">
                                        <thead>
                                            <tr>
                                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 10%;">
                                                    No.
                                                </th>
                                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 10%;">
                                                    ID Jabatan
                                                </th>
                                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 35%;">
                                                    Nama Jabatan
                                                </th>
                                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 30%;">
                                                    Gaji Pokok
                                                </th>
                                                <th class="ui-state-default" rowspan="1" colspan="1" style="width: 15%;">
                                                    Aksi
                                                </th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            
                                                <tr class="gradeA odd">
                                                

                                                    <td>No</td>
                                                    <td>ID Jabatan</td>
                                                    <td>Nama Jabatan</td>
                                                    <td>Gaji Pokok</td>
                                                    <td>
                                                        <a><button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#modalUbah">Ubah</button></a>
                                                        <a onclick="return confirm('Apakah Anda yakin akan menhapus data?')"><button class="btn btn-danger btn-xs ">Hapus</button></a>
                                                    </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div> <!-- .widget-content -->

                        </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->



        <!-- Modal Tambah Jabatan -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Tambah Jabatan</h4>
                    </div>
                    <form action="aksi.php" method="post" name="form1">
                    <div class="modal-body">
                    <input class="form-control" name="akses" type="hidden" value="tambah">                        
                    <div class="form-group">
                            <label>Nama Jabatan</label>
                            <input class="form-control" name="nama_jabatan" id="nama_jabatan" type="text">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Gaji Pokok</label>
                            <input class="form-control" name="gapok" id="gapok" type="text">
                            <p class="help-block"></p>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="Submit" class="btn btn-success">Simpan</button>
                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- ./Modal -->

        <!-- Modal Ubah Jabatan -->
        <div class="modal fade" id="modalUbah" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Tambah Jabatan</h4>
                    </div>
                    <form action="aksi.php" method="post" name="form1">
                    <div class="modal-body">
                    <input class="form-control" name="akses" type="hidden" value="tambah">                        
                    <div class="form-group">
                            <label>Nama Jabatan</label>
                            <input class="form-control" name="nama_jabatan" id="nama_jabatan" type="text">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Gaji Pokok</label>
                            <input class="form-control" name="gapok" id="gapok" type="text">
                            <p class="help-block"></p>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="Submit" class="btn btn-success">Simpan</button>
                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- ./Modal -->

        <!-- Core Scripts - Include with every page -->
        <script src="../assets/js/jquery-1.10.2.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>

        <!-- Page-Level Plugin Scripts - Tables -->
        <script src="../assets/js/plugins/dataTables/jquery.dataTables.js"></script>
        <script src="../assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>

        <!-- SB Admin Scripts - Include with every page -->
        <script src="../assets/js/sb-admin.js"></script>

        <!-- Page-Level Demo Scripts - Blank - Use for reference -->
        <script>
        $(document).ready(function() {
            $('#dataTables-example').dataTable();
        });
        </script>
</body>

</html>