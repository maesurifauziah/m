-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 18, 2019 at 05:40 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sp3`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` varchar(5) NOT NULL COMMENT 'identifies product category',
  `cat_name` varchar(15) NOT NULL COMMENT 'name of the category',
  `cat_desc` varchar(50) NOT NULL COMMENT 'category description'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_desc`) VALUES
('CT001', 'KATEGORI1', 'KATEGORI'),
('CT002', 's', 's'),
('CT003', 'a', 's'),
('CT004', '4', '4'),
('CT005', 'addd', 'daaaa');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` varchar(5) NOT NULL COMMENT 'Uniquely identifies customer',
  `bregno` int(10) NOT NULL COMMENT 'Customer PAN resgister Number',
  `fname` varchar(15) NOT NULL COMMENT 'Firsta name of custome',
  `lname` varchar(15) NOT NULL COMMENT 'Last name of customer',
  `address` varchar(30) NOT NULL COMMENT 'Address of customer retail shop',
  `phone` int(10) NOT NULL COMMENT 'Contact phone of customer',
  `email` varchar(15) DEFAULT NULL COMMENT 'Email address of customer',
  `staff_id` varchar(5) NOT NULL COMMENT 'Staff who registers customer'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `bregno`, `fname`, `lname`, `address`, `phone`, `email`, `staff_id`) VALUES
('C0001', 1234, 'TOKO TUJUH', 'SAMUDRA', 'baleendah', 85, 'tk17@gmail.com', 'SF001');

-- --------------------------------------------------------

--
-- Table structure for table `odetail`
--

CREATE TABLE `odetail` (
  `order_id` int(10) NOT NULL COMMENT 'Identifies order that came in',
  `billno` int(10) NOT NULL COMMENT 'Identifies the bill generated',
  `odetail_id` varchar(5) NOT NULL COMMENT 'Identifies id for order details',
  `product_id` varchar(10) NOT NULL COMMENT 'Identifies each product',
  `usp` int(5) NOT NULL COMMENT 'Unit price of each product unit',
  `size` varchar(1) NOT NULL COMMENT 'Size of product',
  `ord_quant` int(6) NOT NULL COMMENT 'Quantity of product ordered',
  `del_quant` int(6) DEFAULT NULL COMMENT 'Quantity of product delivered',
  `discount` int(3) NOT NULL COMMENT 'Discounts involved',
  `total` int(7) NOT NULL COMMENT 'Total amount of bill',
  `del_date` date NOT NULL COMMENT 'Order dispatch date',
  `ord_date` date NOT NULL COMMENT 'Date when order came'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `odetail`
--

INSERT INTO `odetail` (`order_id`, `billno`, `odetail_id`, `product_id`, `usp`, `size`, `ord_quant`, `del_quant`, `discount`, `total`, `del_date`, `ord_date`) VALUES
(1, 1, '1', 'P0001', 0, 'M', 1, 1, 15, 10000, '2019-10-18', '2019-10-16');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(10) NOT NULL COMMENT 'Uniquely identifies each order',
  `staff_id` varchar(5) NOT NULL COMMENT 'Identifies the sales staff',
  `cid` varchar(5) NOT NULL COMMENT 'Customer id who orders',
  `odate` date NOT NULL COMMENT 'Incoming order date',
  `erromsg` varchar(30) DEFAULT NULL COMMENT 'Error message if happens'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_id`, `staff_id`, `cid`, `odate`, `erromsg`) VALUES
(1, 'SF001', 'C0001', '2019-10-18', 'TES');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `billno` int(10) NOT NULL,
  `pay_type` varchar(10) NOT NULL,
  `cr_amount` int(7) DEFAULT NULL,
  `cr_date` date DEFAULT NULL,
  `dr_amount` int(7) DEFAULT NULL,
  `dr_date` date DEFAULT NULL,
  `balance` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`billno`, `pay_type`, `cr_amount`, `cr_date`, `dr_amount`, `dr_date`, `balance`) VALUES
(1, 'CASH', 10000, '2019-10-18', 5000, '2019-10-18', -5000);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` varchar(10) NOT NULL COMMENT 'Uniquely identifies produc',
  `pname` varchar(15) NOT NULL COMMENT 'Product Name Product',
  `pdescr` varchar(50) NOT NULL COMMENT 'Description Identifies',
  `cat_id` varchar(5) NOT NULL COMMENT 'product category',
  `supplier_id` varchar(5) NOT NULL COMMENT 'Identifies product supplier',
  `qperunit` int(4) NOT NULL COMMENT 'Product quantity per unit',
  `uprice` int(4) NOT NULL COMMENT 'Product unit price',
  `usp` int(4) NOT NULL COMMENT 'Unit Selling price',
  `uweight` int(4) NOT NULL COMMENT 'Product unit weight Product',
  `usize` varchar(1) NOT NULL COMMENT 'unit size, S, M, L Discount',
  `discount` int(3) DEFAULT NULL COMMENT 'offered by supplier Product',
  `uinstock` int(11) NOT NULL COMMENT 'units in stock',
  `uinorder` int(11) NOT NULL COMMENT 'units in order from supplier',
  `reorlevel` int(11) NOT NULL COMMENT 'Product margin for re-ordering',
  `note` varchar(50) DEFAULT NULL COMMENT 'Some note for product'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `pname`, `pdescr`, `cat_id`, `supplier_id`, `qperunit`, `uprice`, `usp`, `uweight`, `usize`, `discount`, `uinstock`, `uinorder`, `reorlevel`, `note`) VALUES
('P0001', 'A', 'B', 'CT001', 'S0001', 1, 1, 1, 1, 'L', 10, 1, 1, 1, 'TES');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role_id` varchar(5) NOT NULL COMMENT 'Uniquely identifies a staff role',
  `role_name` varchar(15) NOT NULL COMMENT 'Job title of the staff',
  `descr` varchar(30) NOT NULL COMMENT 'Description of role'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `role_name`, `descr`) VALUES
('R0001', 'Admin', 'Akses Administrator'),
('R0002', 'User', 'Akses User');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` varchar(5) NOT NULL COMMENT 'Uniquely identifies a member staf',
  `fname` varchar(15) NOT NULL COMMENT 'First Name of Staff',
  `lname` varchar(15) NOT NULL COMMENT 'Last Name of Staff',
  `dob` date NOT NULL COMMENT 'Date of Birth of Staff',
  `address` varchar(30) NOT NULL COMMENT 'Home Address or contact addres',
  `sex` char(1) NOT NULL COMMENT 'Gender Male M or Femal F',
  `phone` int(10) NOT NULL COMMENT 'Contact Phone Number',
  `role_id` varchar(5) NOT NULL COMMENT 'Job Title ID, Foreign Key',
  `username` varchar(15) NOT NULL COMMENT 'Unique to user, for login function',
  `password` varchar(15) DEFAULT NULL COMMENT 'Unique, encrypted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `fname`, `lname`, `dob`, `address`, `sex`, `phone`, `role_id`, `username`, `password`) VALUES
('SF001', 'Admin', 'administratpr', '2019-10-18', 'jl.raa wiranatakusumah no7', 'M', 22595, 'R0001', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` varchar(5) NOT NULL COMMENT 'Uniquely identifies each supplier',
  `com_name` varchar(15) NOT NULL COMMENT 'Supplier company name',
  `conf_name` varchar(15) NOT NULL COMMENT 'Contact person first name',
  `conl_name` varchar(15) NOT NULL COMMENT 'Contact person last name',
  `con_title` varchar(10) NOT NULL COMMENT 'Cont person job title',
  `address` varchar(30) NOT NULL COMMENT 'Address of supplier',
  `phone` int(10) NOT NULL COMMENT 'Suppliers’ phone number',
  `fax` int(11) DEFAULT NULL COMMENT 'Fax number',
  `email` varchar(30) DEFAULT NULL COMMENT 'Email address',
  `pay_meth` varchar(30) NOT NULL COMMENT 'Payment methods',
  `distype` int(3) NOT NULL COMMENT 'Discount type'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `com_name`, `conf_name`, `conl_name`, `con_title`, `address`, `phone`, `fax`, `email`, `pay_meth`, `distype`) VALUES
('S0001', 'SAMUDRA PACIFIC', 'ARTHA', 'DINATA', 'BOGASARI', 'jl merdeka', 87, 21, 'artha@gmail.com', 'CASH', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `bregno` (`bregno`),
  ADD KEY `staf_id` (`staff_id`);

--
-- Indexes for table `odetail`
--
ALTER TABLE `odetail`
  ADD PRIMARY KEY (`odetail_id`),
  ADD KEY `billno` (`billno`,`product_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `staf_id` (`staff_id`,`cid`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`billno`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Uniquely identifies each order', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `billno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`);

--
-- Constraints for table `odetail`
--
ALTER TABLE `odetail`
  ADD CONSTRAINT `odetail_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `odetail_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`),
  ADD CONSTRAINT `odetail_ibfk_4` FOREIGN KEY (`billno`) REFERENCES `payment` (`billno`);

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`cid`) REFERENCES `customer` (`cid`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`);

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
