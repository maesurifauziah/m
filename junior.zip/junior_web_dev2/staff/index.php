<!-- cek apakah sudah login -->
<?php 
    include('../koneksi.php');
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../login/index.php");
    }
    
    ?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>UjiKom Junior Web Programing Universitas Bale Bandung</title>

    <!-- Core CSS - Include with every page -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/datepicker.css" rel="stylesheet">
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Page-Level Plugin CSS - Tables -->
    <link href="../assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <!-- SB Admin CSS - Include with every page -->
    <link href="../assets/css/sb-admin.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../assets/index.html">UjiKom Junior Web Programing Universitas Bale
                    Bandung</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <?php echo $_SESSION['username'];?> <i class="fa fa-user fa-fw"></i> <i
                            class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="login/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="../index.php"><i class="fa fa-home fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="../staff/index.php"><i class="fa fa-user fa-fw"></i> Staff</a>
                        </li>
                        <li>
                            <a href="../customer/index.php"><i class="fa fa-user fa-fw"></i> Customer</a>
                        </li>
                        <li>
                            <a href="../supplier/index.php"><i class="fa fa-user fa-fw"></i> Supplier</a>
                        </li>
                        <li>
                            <a href="../product/index.php"><i class="fa fa-tasks fa-fw"></i> Product</a>
                        </li>
                        <li>
                            <a href="../product_category/index.php"><i class="fa fa-tasks fa-fw"></i> Product
                                Category</a>
                        </li>
                        <li>
                            <a href="../order/index.php"><i class="fa fa-files-o fa-fw"></i> Order</a>
                        </li>
                        <li>
                            <a href="../payment/index.php"><i class="fa fa-edit fa-fw"></i> Payment</a>
                        </li>

                    </ul>
                    <!-- /#side-menu -->
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Staff</h1>
                </div>
                <!-- /.col-lg-12 -->

                <div class="panel-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#myModal">Tambah</button><br /><br />
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Date of Brith</th>
                                    <th>Address</th>
                                    <th>Sex</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $result = mysqli_query($koneksi,"SELECT staff_id,username,fname,lname,dob,address,sex,phone,role_id FROM staff ORDER BY staff_id ASC");
                                    $tabel = "";
                                    while($row = mysqli_fetch_array($result)) {
                                    $tabel = '<tr>
                                                <td>' . $row['staff_id'] . '</td>
                                                <td>' . $row['username'] . '</td>
                                                <td>' . $row['fname'] . '</td>
                                                <td>' . $row['lname'] . '</td>
                                                <td>' . $row['dob'] . '</td>
                                                <td>' . $row['address'] . '</td>
                                                <td>' . $row['sex'] . '</td>
                                                <td>' . $row['phone'] . '</td>
                                                <td>' . $row['role_id'] . '</td>
                                                <td>
                                                <a href="#edit" class="btn btn-info btn-xs item_edit" data="'.$row['staff_id'].'" data-toggle="modal"
                                                data-target="#myModal">Edit</a>'.' '.
                                                '<a href="#pass" class="btn btn-warning btn-xs item_pass" data="'.$row['staff_id'].'" data-toggle="modal"
                                                data-target="#myModalPass">Change Password</a>'.' '.
                                                '<a href="javascript:;" class="btn btn-danger btn-xs item_hapus" data="'.$row['staff_id'].'">Hapus</a>'.
                                                '</td>'.
                                             '</tr>';
                                    }
                                    echo $tabel;
                                    // mysqli_close($koneksi);
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Add Staff</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>ID</label>
                            <input class="form-control" name="staff_id" type="text"
                                value="<?php echo autoNumber($koneksi, 'SF','staff_id','staff');?>">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>First Name</label>
                            <input class="form-control" name="fname">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input class="form-control" name="lname">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Date of Brith</label>
                            <input class="form-control" name="dob" class="datepicker" type="text">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <input class="form-control" name="address">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Sex</label>
                            <select class="form-control" name="sex">
                                <option value="M">Male</option>
                                <option value="F">Female</option>
                            </select>
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Phone</label>
                            <input class="form-control" name="phone">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" name="username">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input class="form-control" name="password" type="password">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select class="form-control" name="role">
                                <?php
                                    $result = mysqli_query($koneksi,"SELECT * FROM role");
                                    $option = "";
                                    while($row = mysqli_fetch_array($result)) {
                                        $option .= "<option value=".$row['role_id'].">".$row['role_name']."</option>";
                                    }
                                    echo $option;
                                    // mysqli_close($koneksi);
                                ?>
                            </select>
                            <p class="help-block"></p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Simpan</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    </div>
                </div>

            </div>
        </div>
        <!-- ./Modal -->
        <!-- Modal -->
        <div class="modal fade" id="myModalPass" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Change Password</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Password old</label>
                            <input class="form-control" name="password1" type="password">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Password New</label>
                            <input class="form-control" name="password2" type="password">
                            <p class="help-block"></p>
                        </div>
                        <div class="form-group">
                            <label>Repeat</label>
                            <input class="form-control" name="password3" type="password">
                            <p class="help-block"></p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Simpan</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    </div>
                </div>

            </div>
        </div>
        <!-- ./Modal -->

    </div>
    <!-- ./wraper -->

    <!-- Core Scripts - Include with every page -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/bootstrap-datepicker.js"></script>
    <script src="../assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Page-Level Plugin Scripts - Tables -->
    <script src="../assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>

    <!-- SB Admin Scripts - Include with every page -->
    <script src="../assets/js/sb-admin.js"></script>

    <!-- Page-Level Demo Scripts - Blank - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            todayBtn: 'linked'
        });

        console.log("");
    });
    </script>
</body>

</html>