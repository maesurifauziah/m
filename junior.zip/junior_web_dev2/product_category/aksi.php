<?php
include('../koneksi.php');

if (isset($_POST['akses'])){
    $akses = $_POST['akses'];
    $id = $_POST['id'];
    $nama = $_POST['names'];
    $desc = $_POST['desc'];
        echo $id;
        echo $nama;
        echo $desc;
    if ($akses == "tambah"){
        $res = mysqli_query($koneksi, "INSERT INTO category (cat_id, cat_name, cat_desc) VALUES ('$id','$nama','$desc')");
        // Show message when user added
        header("location:index.php");

    }

}
?>